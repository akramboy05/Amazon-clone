import img from "../images/1.jpg"
import img2 from "../images/2.jpg"
import img3 from "../images/3.jpg"
import img4 from "../images/4.jpg"

import head from '../images/Headset.jpg'
import keyboard from '../images/keyboard.jpg'
import mouse from '../images/mouse.jpg'
import chair from '../images/chairs.jpg'
import compAccs from '../images/computer&acces.jpg'
import valentine from '../images/valentine.jpg'
import basic from '../images/Basic.jpg'
import IdealTv from '../images/idealTv.jpg'
import electronic from '../images/electronic.jpg'

import book1 from '../images/book1.jpg'
import book2 from '../images/book2.jpg'
import book3 from '../images/book3.jpg'
import book4 from '../images/book4.jpg'
import book5 from '../images/book5.jpg'
import book6 from '../images/book6.jpg'
import book7 from '../images/book7.jpg'
import book8 from '../images/book8.jpg'
import book9 from '../images/book9.jpg'
import book10 from '../images/book10.jpg'
import book11 from '../images/book11.jpg'
import book12 from '../images/book12.jpg'
import book13 from '../images/book13.jpg'
import book14 from '../images/book14.jpg'
import book15 from '../images/book15.jpg'

import watch from '../images/watch.jpg'
import dress1 from '../images/dress1.jpg'
import dress2 from '../images/dress2.jpg'
import dress3 from '../images/dress3.jpg'
import dress4 from '../images/dress4.jpg'
import kindle from '../images/kindle.jpg'
import pet from '../images/pet.jpg'
import gaming1 from '../images/gaming1.jpg'
import gaming2 from '../images/gaming2.jpg'
import gaming3 from '../images/gaming3.jpg'
import gaming4 from '../images/gaming4.jpg'
import fitness from '../images/fitness.jpg'
import toys from '../images/toys.jpg'
import laptop from '../images/laptops.jpg'

import laptop1 from '../images/laptop1.jpg'
import processor1 from '../images/processor1.jpg'
import laptop2 from '../images/laptop2.jpg'
import laptop3 from '../images/laptop3.jpg'
import tab from '../images/tab.jpg'
import laptop8 from '../images/laptop8.jpg'
import tab2 from '../images/tab2.jpg'
import processor from '../images/processor.jpg'
import processor2 from '../images/processor2.jpg'
import laptop4 from '../images/laptop4.jpg'
import tab3 from '../images/tab3.jpg'
import laptop5 from '../images/laptop5.jpg'
import laptop6 from '../images/laptop6.jpg'
import tab4 from '../images/tab4.jpg'
import tab5 from '../images/tab5.jpg'
import laptop7 from '../images/laptop7.jpg'
import laptop9 from '../images/laptop9.jpg'
import tab6 from '../images/tab6.jpg'
import laptop10 from '../images/laptop10.jpg'
import tab7 from '../images/tab7.jpg'
import toy1 from '../images/toy.jpg'
import toy2 from '../images/toy2.jpg'
import toy3 from '../images/toy3.jpg'
import toy4 from '../images/toy4.jpg'

import tv1 from '../images/TV/tv1.jpg'
import tv2 from '../images/TV/tv2.jpg'
import tv3 from '../images/TV/tv3.jpg'
import tv4 from '../images/TV/tv4.jpg'
import tv5 from '../images/TV/tv5.jpg'
import tv6 from '../images/TV/tv6.jpg'
import tv7 from '../images/TV/tv7.jpg'
import tv8 from '../images/TV/tv8.jpg'
import tv9 from '../images/TV/tv9.jpg'
import tv10 from '../images/TV/tv10.jpg'
import tv11 from '../images/TV/tv11.jpg'
import tv12 from '../images/TV/tv12.jpg'
import tv13 from '../images/TV/tv13.jpg'
import tv14 from '../images/TV/tv14.jpg'
import tv15 from '../images/TV/tv15.jpg'
import tv16 from '../images/TV/tv16.jpg'
import tv17 from '../images/TV/tv17.jpg'
import tv18 from '../images/TV/tv18.jpg'
import tv19 from '../images/TV/tv19.jpg'
import tv20 from '../images/TV/tv20.jpg'
import tv21 from '../images/TV/tv21.jpg'
import tv22 from '../images/TV/tv22.jpg'
import tv23 from '../images/TV/tv23.jpg'
import tv24 from '../images/TV/tv24.jpg'

//Watch
import watch1 from '../images/Watch/watch1.jpg'
import watch2 from '../images/Watch/watch2.jpg'
import watch3 from '../images/Watch/watch3.jpg'
import watch4 from '../images/Watch/watch4.jpg'
import watch5 from '../images/Watch/watch5.jpg'
import watch6 from '../images/Watch/watch6.jpg'
import watch7 from '../images/Watch/watch7.jpg'
import watch8 from '../images/Watch/watch8.jpg'
import watch9 from '../images/Watch/watch9.jpg'
import watch10 from '../images/Watch/watch10.jpg'
import watch11 from '../images/Watch/watch11.jpg'
import watch12 from '../images/Watch/watch12.jpg'
import watch13 from '../images/Watch/watch13.jpg'
import watch14 from '../images/Watch/watch14.jpg'
import watch15 from '../images/Watch/watch15.jpg'
import watch16 from '../images/Watch/watch16.jpg'
import watch17 from '../images/Watch/watch17.jpg'
import watch18 from '../images/Watch/watch18.jpg'
import watch19 from '../images/Watch/watch19.jpg'
import watch20 from '../images/Watch/watch20.jpg'
import watch21 from '../images/Watch/watch21.jpg'
import watch22 from '../images/Watch/watch22.jpg'
import watch23 from '../images/Watch/watch23.jpg'


export const navbarOptions = [
    {
        id: 0,
        name: "All"
    },
    {
        id: 1,
        name: "All Departments"
    },
    {
        id: 2,
        name: "Arts & Crafts"
    },
    {
        id: 3,
        name: "Automotive"
    },
    {
        id: 4,
        name: "Beauty & Personal Care"
    },
    {
        id: 5,
        name: "Books"
    },
    {
        id: 6,
        name: "Boy's Fashion"
    },
    {
        id: 7,
        name: "Computers"
    },
    {
        id: 8,
        name: "Deals"
    },
    {
        id: 9,
        name: "Digital Music"
    },
    {
        id: 10,
        name: "Electronics"
    },
    {
        id: 11,
        name: "Girl's Fashion"
    },
    {
        id: 12,
        name: "Health & Household"
    },
    {
        id: 13,
        name: "Home & Kitchen"
    },
    {
        id: 14,
        name: "Indistrual & Scientific"
    },
    {
        id: 15,
        name: "Kindle Store"
    },
    {
        id: 16,
        name: "Luggage"
    },
    {
        id: 17,
        name: "Men's Fashionmovies-tv-intl-ship"
    },
    {
        id: 18,
        name: "Music , CD & Vinyl"
    },
    {
        id: 19,
        name: "Pett Sulies"
    },
    {
        id: 20,
        name: "Prime Video"
    },
    {
        id: 21,
        name: "Software"
    },
    {
        id: 22,
        name: "Sports & Outdoors"
    },
    {
        id: 23,
        name: "Prime Video"
    },
    {
        id: 24,
        name: "Tools & Improvement"
    },
    {
        id: 25,
        name: "Toys & Games"
    },
    {
        id: 26,
        name: "Video Games"
    },
    {
        id: 27,
        name: "Women's  Fashion"
    },

]

export const carusel = [
    {
        id: 0,
        img: img
    },
    {
        id: 1,
        img: img2
    },
    {
        id: 2,
        img: img3
    },
    {
        id: 3,
        img: img4
    }

]

export const countrySelect =[
   {id:0, name:"Uzbekiston"},
   {id:1, name:"Afg'oniston"},
   {id:2, name:"Albania"},
   {id:3, name:"America Qo'shma Shtatlari"},
   {id:4, name:"America Samoasi"},
   {id:5, name:"Andorra"},
   {id:6, name:"Anglia"},
   {id:7, name:"Angola"},
   {id:8, name:"Antigua va Barbuda"},
   {id:9, name:"Argentina"},
   {id:10, name:"Armaniston"},
   {id:11, name:"Belarus"},
   {id:12, name:"Barbados"},
   {id:13, name:"Belgiya"},
   {id:14, name:"Bolgariya"},
   {id:15, name:"Birlashgan Arab Amirliklari"},
   {id:16, name:"Braziliya"},
   {id:17, name:"Eron"},
   {id:18, name:"Gruziya"},
   {id:19, name:"Hindiston"},
   {id:20, name:"Iroq"},
   {id:21, name:"Italiya"},
   {id:22, name:"Isroil"},
   {id:23, name:"Janubiy Koreya"},
   {id:24, name:"Janubiy Sudan"},
   {id:25, name:"Chexiya"},
   {id:26, name:"Qozog'iston"},
   {id:27, name:"Qirg'iziston"},
   {id:28, name:"Rossiya"},
   {id:29, name:"Polsha"},
   {id:30, name:"Yaponiya"},
]

export const footerCenterCollection=[
   {id:0, name:"Get to Know Us", desc:"Careers",desc2:"Blog",desc3:"About Amazon", desc4:"Investor Relations", desc5:"Amazon Devices",desc6: "Amazon Science"},
   {id:1, name:"Make Money with Us", desc:"Sell products on Amazon", desc2:"Sell on Amazon Business", desc3:"Sell apps on Amazon", desc4:"Become an Affiliate", desc5:"Advertise Your Products", desc5:"Self-Publish with Us", desc6:"Host an Amazon Hub", desc7:"See more Make Money with Us"},
   {id:2, name:"Amazon Payment Products", desc:"Amazon Business Card",desc2:"Shop with Points", desc3:"Reload Your Balance",desc4: "Amazon Currency Converter"},
   {id:3, name:"Let Us Help you", desc:"Amazon and COVID-19",desc2:"Your Account",desc3: "Your Orders", desc4:"Shipping rates & Policies", desc5:"Returns & Replacements", desc6:"Manage your Content and Devices", desc7:"Amazon Assistant", desc8:"Help"}
]

export const footerBottomCollection=[
   {id:0, name:"Amazon Music", desc:"Stream millions", desc1:"of songs"},
   {id:1, name:"Amazon Advertising", desc:"find attract", desc1:"and engage customers"},
   {id:2, name:"Amazon Drive", desc:"Cloud Storage", desc1:"from Amazon"},
   {id:3, name:"6pm", desc:"Score deals", desc1:"on fashion", desc2:"brands"},
   {id:4, name:"AbeBooks", desc:"Books, art", desc1:"& collectibles"},
   {id:5, name:"ACX", desc:"AudioBook", desc1:"Publishing", desc2:"Made Easy"},
   {id:6, name:"Alexa", desc:"Actionable", desc1:"Analytics", desc2:"for the Web"},
   {id:7, name:"Sell on Amazon", desc:"Start a Selling ", desc1:"Account"},
   {id:8, name:"Amazon Business", desc:"Everything For", desc1:"Your Business"},
   {id:9, name:"AmazonGlobal", desc:"Ship Orders", desc1:"Internationally"},
   {id:10, name:"Home Services", desc:"Experienced", desc1:"Pros", desc2:"Happiness", desc3:"Guarentee"},
   {id:11, name:"Amazon Ignite", desc:"Sell your original", desc1:"Digital Educational", desc2:"Resources"},
   {id:12, name:"Amazon Web", desc:"Services", desc1:"Scalable Cloud", desc2:"Computing Services"},
   {id:13, name:"Audible", desc:"Listen to Books &", desc1:"Original", desc2:"Audio", desc3:"Performances" },
   {id:14, name:"Book Depository", desc:"Books with free", desc1:"Delivery", desc2:"Worldwide"},
   {id:15, name:"Box office Mojo", desc:"Find Movie", desc1:"Box office Data"},
   {id:16, name:"ComiXology", desc:"Thousands of", desc1:"Digital Comics"},
   {id:17, name:"DPReview", desc:"Digital", desc1:"Photography"},
   {id:18, name:"Fabric", desc:"Sewing,Quilting", desc1:"& Knitting"},
   {id:19, name:"Goodreads", desc:"Book reviews", desc1:" & recomendations"},
   {id:20, name:"IMDb", desc:"Movies, TV", desc1:"& Celebrities"},
   {id:21, name:"IMDbPro", desc:"Get Info", desc1:"Entertaiment", desc2:"Professionals", desc3:"Need"},
   {id:22, name:"Kindle Direct Publishing", desc:"Indie Digital & Print", desc1:"Publishing", desc2:"Made Easy"},
   {id:23, name:"Prime Video Direct", desc:"Video Distribution", desc1:"Made Easy"},
   {id:24, name:"ShopBop", desc:"Designer", desc1:"Fashio Brands"},
   {id:25, name:"Woot!", desc:"Deals and ", desc1:"Shenaginas"},
   {id:26, name:"Zappos", desc:"Shoes &", desc1:"Clothing"},
   {id:27, name:"Ring ", desc:"Smart Home", desc1:"Security Systems", },
   {id:28, name:"eero Wifi", desc:"Stream 4k Video", desc1:"in Every Room"},
   {id:29, name:"eero Wifi", desc:"Stream 4k Video", desc1:"in Every Room"},
   {id:30, name:"eero Wifi", desc:"Stream 4k Video", desc1:"in Every Room"},
   {id:31, name:"eero Wifi", desc:"Stream 4k Video", desc1:"in Every Room"}
//    {id:28, name:"dhhsh", desc:"hchs", desc1:"gsdhsgh", desc2:"hshhs", desc3:"hchsg", desc4:"sgha"}
]

export const sidebarFirstData =[
    {
        "id": 0,
        "name": "Amazon Music"
        
    },
    {
        "id": 1,
        "name": "Kindle E-readers & Books"
    },
    {
        "id": 2,
        "name": "Appstore for Android"
    },
    {
        "id": 3,
        "name": "Electronics"
    },
    {
        "id": 4,
        "name": "Computers"
    },
    {
        "id": 5,
        "name": "Smart Home"
    },
    {
        "id": 6,
        "name": "Arts & Crafts"
    },
    {
        "id": 7,
        "name": "See All"
    },
    {
        "id": 8,
        "name": "Gift Cards"
    },
    {
        "id": 9,
        "name": "#FoundInAmazon"
    },
    {
        "id": 10,
        "name": "Amazon Live"
    },
    {
        "id": 11,
        "name": "International Shopping"
    },
    {
        "id": 12,
        "name": "See All"
    },
]


export const sidebarSecondData = [
    {
        "id": 0,
        "header": "MAIN MENU",
        "title": "Stream Music",
        "items": ["Amozon Music HD", "Amozon Music Prime","Free Streaming music","Podcasts","Prime Member Deals","Open Web Palyer",]
        
    },
    {
        "id": 1,
        "header": "MAIN MENU",
        "title": "Kindle E-readers",
        "items": ["Kindle Kids", "Kindle", "Kindle Peparwhite", "Kindle Oasis", "Accessories"]
    },
    {
        "id": 2,
        "header": "MAIN MENU",
        "title": "Appstore for Android",
        "items": ["All Apps and Game", "Games","Amazon Coins","Download Amazon Appstore","Amazon Apps" ]
    },
    {
        "id": 3,
        "header": "MAIN MENU",
        "title": "Electronics",
        "items": ["All Apps and Game", "Games","Amazon Coins","Download Amazon Appstore","Amazon Apps" ]
    },
    {
        "id": 4,
        "header": "MAIN MENU",
        "title": "Computers",
        "items": ["Lenova","HP","Aser","Mac","Fujitsu","Samsung","Galaxy","UltraBook","LG","Tokyo", "All Apps and Game", "Games","Amazon Coins","Download Amazon Appstore","Amazon Apps" ]
    },
    {
        "id": 5,
        "header": "MAIN MENU",
        "title": "Smart Home",
        "items": ["All Apps and Game", "Games","Amazon Coins","Download Amazon Appstore","Amazon Apps" ]
    },
    {
        "id": 6,
        "header": "MAIN MENU",
        "title": "Arts & Crafts",
        "items": ["All Apps and Game", "Games","Amazon Coins","Download Amazon Appstore","Amazon Apps" ]
    },
    {
        "id": 7,
        "header": "MAIN MENU",
        "title": "See All",
        "items": ["All Apps and Game", "Games","Amazon Coins","Download Amazon Appstore","Amazon Apps" ]
    },
    {
        "id": 8,
        "header": "MAIN MENU",
        "title": "Gift Cards",
        "items": ["All Apps and Game", "Games","Amazon Coins","Download Amazon Appstore","Amazon Apps" ]
    },
    {
        "id":9,
        "header": "MAIN MENU",
        "title": "#FoundInAmazon",
        "items": ["All Apps and Game", "Games","Amazon Coins","Download Amazon Appstore","Amazon Apps" ]
    },
    {
        "id": 10,
        "header": "MAIN MENU",
        "title": "Amazon Live",
        "items": ["All Apps and Game", "Games","Amazon Coins","Download Amazon Appstore","Amazon Apps" ]
    },
    {
        "id": 11,
        "header": "MAIN MENU",
        "title": "International Shopping",
        "items": ["All Apps and Game", "Games","Amazon Coins","Download Amazon Appstore","Amazon Apps" ]
    },
    {
        "id": 12,
        "header": "MAIN MENU",
        "title": "See All",
        "items": ["All Apps and Game", "Games","Amazon Coins","Download Amazon Appstore","Amazon Apps" ]
    },
]

export const productWrapper=[
  
    {
        id:1,
        title: "Gaming accessories",
        image:[head, keyboard, mouse, chair],
        grid:true
    },
    {
        id:2,
        title: "Shop by Category",
        image:[toy2,toy3,toy4,toy1],
        grid:true
    },
    {
        id:0,
        title: "Computers & Accessories",
        image:compAccs,
        grid:false
    },
    {
        id:3,
        title: "Shop Valentine's Day",
        image:valentine,
        grid:false
    },
    {
        id:4,
        title: "AmazonBasics",
        image:basic,
        grid:false
    },
    {
        id:5,
        title: "Find your ideal TV",
        image:IdealTv,
        grid:false
    },
    {
        id:6,
        title: "Electronics",
        image:electronic,
        grid:false
    },
    {
        id:7,
        title: "Computers & Accessories",
        image:img,
        grid:false
    },
  
]

export const electronicSidebarData =[
    {
        id:0,
        title:["Computer Accessories &", "Peripherals", "Computer Components", "Computers & Tablets","Data Storage", "Laptop Accessories", "Monitors", "Networking Products", "Power Strips & Surge", "Protectors", "Printers", "Scanners", "Servers", "Tablet Accessories", "Tablet Replacement Parts", "Warranties & Services", "Climate Pledge Friendly", "Auto Replenishment", "Works with Alexa", "Our Brands", "TAKAGI", "Seagate", "HP", "Roku","Apple", "Logitech", "SanDisk"], 
        h3:"Avg. Customer Review"
        
    }
]

export const Amazon_books=[
    {
        id:0,
        img:book1
    },
    {
        id:1,
        img:book2
    }, 
    {
        id:2,
        img:book3
    },
    {
        id:3,
        img:book4
    },
    {
        id:4,
        img:book5
    },
    {
        id:5,
        img:book6
    },
    {
        id:6,
        img:book7
    },
    {
        id:7,
        img:book8
    },
    {
        id:8,
        img:book9
    },
    {
        id:9,
        img:book10
    },
    {
        id:10,
        img:book11
    },
    {
        id:11,
        img:book12
    },
    {
        id:12,
        img:book13
    },
    {
        id:13,
        img:book14
    },
    {
        id:14,
        img:book15
    },
]
export const product_last =[
    {
        id:0,
        title: "Shop activity trackers and smartwatches",
        image:watch,
        grid:false
    },
    {
        id:1,
        title: "Comfy styles for her",
        image:[dress1, dress2, dress3, dress4],
        grid:true
    },
    {
        id:2,
        title: "Kindle E readers",
        image:kindle,
        grid:false
    },
    {
        id:3,
        title: "Shop Pet supplies",
        image:pet,
        grid:false
    },
    {
        id:4,
        title: "Gaming merchandise",
        image:[gaming1,gaming2, gaming3, gaming4],
        grid:true
    },
    {
        id:5,
        title: "For your Fitness Needs",
        image:fitness,
        grid:false
    },
    {
        id:6,
        title: "New arrivals in Toys",
        image:toys,
        grid:false
    },
    {
        id:0,
        title: "Shop Laptops & Tablets",
        image:laptop,
        grid:false
    },
]

export const elecProducts=[
    {
        id: 0,
        img: laptop1, 
        title:"Acer Nitro 5 AN515-55-53E5 Gaming Laptop | Intel Core i5-10300H | NVIDIA GeForce RTX 3050 Laptop GPU | 15.6 FHD 144Hz IPS Display | 8GB DDR4 | 256GB NVMe SSD | Intel Wi-Fi 6 | Backlit Keyboard",
        sell:"1300 $",
        p:"Visit the Acer Store",
        about:["Dominate the Game: With the 10th Gen Intel Core i5-10300H processor, your Nitro 5 is packed with incredible power for all your games",
        "RTX, It's On: The latest NVIDIA GeForce RTX 3050 (4GB dedicated GDDR6 VRAM) is powered by award-winning architecture with new Ray Tracing Cores, Tensor Cores, and streaming multiprocessors support DirectX 12 Ultimate for the ultimate gaming performance",
        "Visual Intensity: Explore game worlds in Full HD detail on the 15.6 widescreen LED-backlit IPS display with 1920 x 1080 resolution, 144Hz refresh rate and 80% screen-to-body, 16:9 aspect ratio",
    ]
    },
    {
        id: 1,
        img: processor1, 
        title:"CYBERPOWERPC Gamer Xtreme VR Gaming PC, Intel Core i5-11400F 2.6GHz, 8GB DDR4, GeForce RTX 2060 6GB, 500GB NVMe SSD, WiFi Ready & Win 11 Home (GXiVR8060A11)",
        sell:"$ 1,014",
        p:"Visit the CyberpowerPC Store"
    },
    {
        id:2,
        img:laptop2,
        title:"Acer Predator Helios 300 PH315-54-760S Gaming Laptop | Intel i7-11800H | NVIDIA GeForce RTX 3060 Laptop GPU | 15.6 Full HD 144Hz",
        sell:"$ 1,375",
        p:"Visit the Acer Store"
    },
    {
        id:3, 
        img:laptop3,
        title:"HP Pavilion 15 Laptop, 11th Gen Intel Core i7-1165G7 Processor, 16 GB RAM, 515 GB SSD Storage, Full HD IPS Micro-Edge Display, Window",
        sell:"$ 900,99",
        p:"Visit the HP Store"
    },
    {
        id:4,
        img:tab,
        title:"SAMSUNG Galaxy Tab S7 11-inch Android Tablet 128GB Wi-Fi Bluetooth S Pen Fast Charging USB-C Port, Mystic Black",
        sell:"$ 275,99",
        p:"Visit the Samsung Electronics Store"
    },
    {
        id:5,
        img:laptop8,
        title:"HP 14 Laptop, AMD Ryzen 5 5500U, 8 GB RAM, 256 GB SSD Storage, 14-inch Full HD Display, Windows 11 Home, Thin & Portable, Micro-Edge",
        sell:"$ 459,99",
        p:"Visit the HP Store"
    }, 
    {
        id:6,
        img:tab2,
        title:"Acer Chromebook Spin 311 Convertible Laptop, Intel Celeron N4020, 11.6 HD Touch, 4GB LPDDR4, 32GB eMMC, Gigabit Wi-Fi",
        sell:" $ 230,99",
        p:"Visit the Acer Store"
    }, 
    {
        id:7, 
        img:processor,
        title:"Acer Aspire TC-1660-UA92 Desktop | 10th Gen Intel Core i5-10400 6-Core Processor | 12GB 2666MHz DDR4 | 512GB NVMe M.2 SSD | 8X DVD |",
        sell:"$ 546,46",
        p:"Visit the Acer Store"
    }, 
    {
        id:8,
        img:processor2,
        title:"CYBERPOWERPC Gamer Xtreme VR Gaming PC, Intel Core i5-11600KF 3.9GHz, 16GB DDR4, GeForce RTX 3060 12GB, 500GB NVMe SSD, 1TB",
        sell:"$ 650,99",
        p:"Visit the Acer Store"
    },
    {
        id:9, 
        img:laptop4,
        title:"Acer Aspire 5 A515-56-36UT Slim Laptop | 15.6 Full HD Display | 11th Gen Intel Core i3-1115G4 Processor | 4GB DDR4 | 128GB NVMe SSD | WiFi",
        sell:"$ 367,99",
        p:"Visit the Acer Store"
    },
    {
        id:10, 
        img:tab3,
        title:"Samsung Galaxy Tab A7 10.4 Wi-Fi 32GB Silver (SM-T500NZSAXAR)",
        sell:"$ 200",
        p:"Visit the Samsung Store"

    }, 
    {
        id:11, 
        img:laptop5, 
        title:"Acer Swift 3 Thin & Light Laptop | 14 Full HD IPS 100% sRGB Display | AMD Ryzen 7 5700U Octa-Core Processor | 8GB LPDDR4X | 512GB",
        sell:" $ 698,00",
        p:"Visit the Acer Store"

    }, 
    {
        id:12, 
        img:laptop6,
        title:"Lenovo IdeaPad 3 Laptop, 14.0 FHD Display, AMD Ryzen 5 5500U, 8GB RAM, 256GB Storage, AMD Radeon 7 Graphics, Windows 11 Home, Abyss",
        sell:'$ 580,99',
        p:"Visit the Lenovo Store"

    }, 
    {
        id:13, 
        img:tab4, 
        title:"Samsung Galaxy Tab S6 Lite 10.4, 64GB Wi-Fi Tablet Oxford Gray - SM-P610NZAAXAR - S Pen Included",
        sell:"$ 130",
        p:"Visit the Samsung Store"

    }, 
    {
        id:14, 
        img:tab5,
        title:"Galaxy Tab S7 FE 2021 Android Tablet 12.4” Screen WiFi 64GB S Pen Included Long-Lasting Battery Powerful Performance, Mystic Black",
        sell:"$260, 00",
        p:"Visit the Samsung Store"

    }, 
    {
        id:15, 
        img:laptop7,
        title:"HP 24-inch All-in-One Desktop Computer, AMD Athlon Silver 3050U Processor, 8 GB RAM, 256 GB SSD, Windows 10 Home (24-dd0010,",
        sell:"$ 529,99",
        p:"Visit the HP Store"

    }, 
    {
        id:16, 
        img:laptop9, 
        title: "Lenovo Flex 5 Laptop, 14.0 FHD Touch Display, AMD Ryzen 5 5500U, 16GB RAM, 256GB Storage, AMD Radeon Graphics, Windows 11 Home",
        sell:"$ 799,00",
        p:"Visit the Lenovo Store"
    }, 
    {
        id:17, 
        img:tab6, 
        title:"Samsung Galaxy Tab A8 Android Tablet, 10.5” LCD Screen, 32GB Storage, Long-Lasting Battery, Samsung Kids Content, Smart Switc",
        sell:"$ 299,99",
        p:"Visit the Samsung Store"
    }, 
    {
        id:18,
        img:laptop10, 
        title:"ASUS ROG Strix G15 (2021) Gaming Laptop, 15.6” 300Hz IPS Type FHD Display, NVIDIA GeForce RTX 3070, AMD Ryzen R9-5900HX, 32GB DDR4", 
        sell:"$ 2,049,49",
        p:"Visit the ASUS Store"
    }, 
    {
        id:19, 
        img:tab7, 
        title:"Tablet 10 inch Android Tablet, Android 10.0 Tablet Quad-Core Processor 32GB Storage Tablet Computer, 2GB RAM, 8MP Camera",
        sell:"$ 210,00",
        p:"Visit the Samsung Store"
    }

]

export const TvPage =[
    {
        id:0,
        img:tv1,
        title:"VIZIO 65-Inch V-Series 4K UHD LED HDR Smart TV with Apple AirPlay and Chromecast Built-in, Dolby Vision, HDR10+, HDMI 2.1, Auto"
    },
    {
        id:1,
        img:tv2,
        title:"TCL 32-inch 3-Series 720p Roku Smart TV - 32S335, 2021 Model"
    },
    {
        id:2,
        img:tv3,
        title:"TCL 50-inch Class 4-Series 4K UHD Smart Roku LED TV - 50S435, 2021 Model"
    },
    {
        id:3,
        img:tv4,
        title:"LG OLED C1 Series 65” Alexa Built-in 4k Smart TV (3840 x 2160), 120Hz Refresh Rate, AI-Powered 4K, Dolby Cinema, WiSA Ready, Gaming Mode"
    },
    {
        id:4,
        img:tv5,
        title:"SAMSUNG 65-Inch Class Crystal UHD AU8000 Series - 4K UHD HDR Smart TV with Alexa Built-in (UN65AU8000FXZA, 2021 Model)"
    },
    {
        id:5,
        img:tv6,
        title:"SAMSUNG 40-inch Class LED Smart FHD TV 1080P (UN40N5200AFXZA, 2019 Model)"
    }, 
    {
        id:6, 
        img:tv7, 
        title:"TCL 32-inch Class 3-Series HD LED Smart Android TV - 32S334, 2021 Model"
    }, 
    {
        id:7,
        img:tv8, 
        title:"SAMSUNG 43-Inch Class QLED Q60A Series - 4K UHD Dual LED Quantum HDR Smart TV with Alexa Built-in (QN43Q60AAFXZA, 2021 Model)"
    }, 
    {
        id:8,
        img:tv9,
        title:"SAMSUNG 55-Inch Class Frame Series - 4K Quantum HDR Smart TV with Alexa Built-in (QN55LS03AAFXZA, 2021 Model)"
    },
    {
        id:9,
        img:tv10,
        title:"LG UP8770 86-in 4K UHD 4K UHD 120Hz Smart TV 86UP8770PUA (2021)"
    }, 
    {
        id:10,
        img:tv11,
        title:"Hisense 43-Inch Class R6090G Roku 4K UHD Smart TV with Alexa Compatibility (43R6090G, 2020 Model)"
    }, 
    {
        id:11, 
        img:tv12,
        title:"SAMSUNG 85-Inch Class Neo QLED QN90A Series - 4K UHD Quantum HDR 32x Smart TV with Alexa Built-in (QN85QN90AAFXZA, 2021 Model),"
    }, 
    {
        id:12, 
        img:tv13, 
        title:"TCL 43-inch Class 4-Series 4K UHD HDR Smart Android TV - 43S434, 2021 Model"
    },
    {
        id:13, 
        img:tv14, 
        title:"VIZIO 65-Inch M6 Series Premium 4K UHD Quantum Color LED HDR Smart TV with Apple AirPlay and Chromecast Built-in, Dolby Vision,"
    }, 
    {
        id:14, 
        img:tv15,
        title:"SAMSUNG 75-Inch Class QLED Q70A Series - 4K UHD Quantum HDR Smart TV with Alexa Built-in (QN75Q70AAFXZA, 2021 Model)"
    }, 
    {
        id:15, 
        img:tv16,
        title:"Sony X80J 75 Inch TV: 4K Ultra HD LED Smart Google TV with Dolby Vision HDR and Alexa Compatibility KD75X80J- 2021 Model"
    }, 
    {
        id:16, 
        img:tv17, 
        title:"SAMSUNG 65-Inch Class QLED Q80A Series - 4K UHD Direct Full Array Quantum HDR 12x Smart TV with Alexa Built-in and 6 Speaker Object"
    }, 
    {
        id:17, 
        img:tv18,
        title:"Sony X90J 65 Inch TV: BRAVIA XR Full Array LED 4K Ultra HD Smart Google TV with Dolby Vision HDR and Alexa Compatibility XR65X90J-"
    }, 
    {
        id:18,
        img:tv19,
        title:"TCL 75-inch 5-Series 4K UHD Dolby Vision HDR QLED Roku Smart TV - 75S535, 2021 Model"
    },
    {
        id:19, 
        img:tv20,
        title:"TCL 55-inch 6-Series 4K UHD Dolby Vision HDR QLED Roku Smart TV - 55R635, 2021 Model , Black"
    },
    {
        id:20,
        img:tv21,
        title:"SAMSUNG 65-Inch Class Neo QLED QN85A Series - 4K UHD Quantum HDR 24x Smart TV with Alexa Built-in and 6 speaker Object Tracking Soun",
    },
    {
        id:21,
        img:tv22,
        title:"SAMSUNG 32-inch Class LED Smart FHD TV 1080P (UN32N5300AFXZA, 2018 Model)"
    },
    {
        id:22, 
        img:tv23, 
        title:"SAMSUNG M5 Series 32-Inch FHD 1080p Smart Monitor & Streaming TV (Tuner-Free), Netflix, HBO, Prime Video, & More, Apple Airplay,"
    }, 
    {
        id:23,
        img:tv24, 
        title:"LG OLED G1 Series 65” Alexa Built-in 4k Smart OLED evo TV (3840 x 2160), Gallery Design, 120Hz Refresh Rate, AI-Powered 4K, Dolby Cinema,"
    }

]

export const watchData =[
    {
        id:0,
        img:watch1,
        title:"Pradory Smart Watch,Fitness Tracker for Android Phones,Activity Tracker with Heart Rate Blood Pressure Monitor IP67 Waterproof Bluetooth Smartwatch 1.6 Touch Screen Sports SmartWatch Men Women Black"
    }, 
    {
        id:1,
        img:watch2,
        title:"Smart Watch for Woman, HolaDream HD Touch Screen Smartwatch Fitness Activity Tracker 5ATM Waterproof Heart Rate/Sleep/Calorie/Blood Oxygen Monitor Pedometer for Android iOS Girls Lady (Grey)"
    },
    {
        id:2,
        img:watch3,
        title:"Pradory Smart Watch,2022 Fitness Watch Activity Tracker with Heart Rate Blood Pressure Monitor IP67 Waterproof Bluetooth Smartwatch for Android iOS Phones Touch Screen Sports Watch Men Women Black"
    },
    {
        id:3,
        img:watch4,
        title:"Smart Watch for Android iOS Phones Compatible iPhone Samsung, Nanphn 1.75'' Touchscreen Sport Smartwatch Fitness Activity Tracker Watch with Call/SMS/Heart Rate/Pedometer for Men Women Kid"
    },
    {
        id:4, 
        img:watch5, 
        title:"Fitbit Versa 2 Health and Fitness Smartwatch with Heart Rate, Music, Alexa Built-In, Sleep and Swim Tracking, Petal/Copper Rose, One Size (S and L Bands Included)"
    },
    {
        id:5,
        img:watch6,
        title:"Smart Watch for Women, AGPTEK Smartwatch for Android and iOS Phones IP68 Waterproof Activity Tracker with Full Touch Color Screen Heart Rate Monitor Pedometer Sleep Monitor, Pink, LW11"
    },
    {
        id:6, 
        img:watch7, 
        title:"2022 Smart Watch with Alexa Built-in for Android Phones and iPhone Compatible, 5ATM Waterproof Activity Tracker with 24/7 Heart Rate, Blood Oxygen, Smartwatch for Men, Valentines Gifts for Him/Her"
    }, 
    {
        id:7, 
        img:watch8,
        title:"Kummel Smart Watch for Women Men, Activity Tracker with Heart Rate Monitor, Spo2 and Sleep Monitoring, IP68 Waterproof Swimming Smartwatch Compatible with iPhone & Android Black"
    },
     {
        id:8, 
        img:watch9,
        title:"suinsist Smart Watch 2022 with Call, Fitness Tracker with Sleep Monitor, ActivityTracker with1.54 InchTouch HD Screen, IP67 Waterproof Pedometer Smartwatch with Step Monitor (Blk Stainless Steel)"
    }, 
    {
        id:9, 
        img:watch10, 
        title:"RIVERSONG Smart Watch for Women, 5ATM Waterproof Watch for Android iOS Phone, Blood Oxygen Heart Rate Sleep Monitor Activity Fitness Tracker Smartwatch with 1.69 inch HD Screen, Motive 3S"
    }, 
    {
        id:10,
        img:watch11, 
        title:"Smart Watch for Android Phones iPhone Compatible, woednx 1.69”Smartwatch Activity Tracker Fitness Smart Watches for Women Men,IP68 Waterproof Watch Pedometer Heart Rate Sleep Monitor (Black)"
    }, 
    {
        id:11,
        img:watch12,
        title:"Smart Watch for Men with GPS,Activity Trackers and Smart Watches with Heart Rate Blood Sleep Monitor,Multi Sports Step Fitness Tracker Smartwatch Compatible with Android Phones and"
    }, 
    {
        id:12,
        img:watch13, 
        title:"Smart Watch 2021 for Men Women, Fitness Tracker 1.69 Touch Screen Smartwatch Fitness Watch IP68 Waterproof 24 Sports, Heart Rate Monitor/Pedometer/Sleep Monitor, Activity Tracker for Android iPhone"
    },
    {
        id:13, 
        img:watch14, 
        title:"Fitness Watches for Women and Men Smart Watch Fitness Tracker Activity Watch and Heart Rate Monitor Waterproof Smart Bracelet with Sleep Monitor Pedometer Calorie Stopwatch with 16 Sport Modes"
    },
    {
        id:14, 
        img:watch15, 
        title:"Smart Watch, KALINCO Fitness Tracker with Heart Rate Monitor, Blood Pressure, Blood Oxygen Tracking, 1.4 Inch Touch Screen Smartwatch Fitness Watch for Women Men Compatible with Android iPhone iOS"
    }, 
    {
        id:15, 
        img:watch16,
        title:"iTouch Air 3 Smartwatch Fitness Tracker, Heart Rate, Step Counter, Sleep Monitor, Message, IP68 Swimming Waterproof for Women and Men, Touch Screen, Compatible with iPhone and Android (40mm)"
    }, 
    {
        id:16,
        img:watch17, 
        title:"Garmin Venu Sq, GPS Smartwatch with Bright Touchscreen Display, Up to 6 Days of Battery Life, Light Gold and White"
    }, 
    {
        id:17,
        img:watch18,
        title:"HAFURY Women Smart Watch, Activity Fitness Tracker for Women Men, Smartwatch for Android & iOS Phones, Heart Rate Monitor, IP68 Waterproof Fitness Watch, Sleep, Calories, Step Tracker, Pink"
    }, 
    {
        id:18,
        img:watch19,
        title:"Smart Watch for Men IP68 Waterproof Smartwatch for iOS Android Phone Fitness Tracker with 1.32'' Large Touch Screen Health Activity Tracker with Heart Rate Sleep Monitor Pedometer Calories Black"
    }, 
    {
        id:19, 
        img:watch20,
        title:"Smart Watch for Android Phones Compatible iPhone Samsung, Health Sport Watches for Men Women GPS Run Activity Fitness Tracker with Blood Pressure Heart Rate Monitor, Replaceable Watch Face and Band"
    }, 
    {
        id:20,
        img:watch21,
        title:"Togala Smart Watch, 1.69 Touch Screen Fitness Watches for Women Sports, Fitness Tracker Smartwatch with Sleep Heart Rate Monitor Activity, IP67 Waterproof, Compatible for Android and iOS Phones, Pink"
    }, 
    {
        id:21,
        img:watch22, 
        title:"LONGLU Smart Watch for Women, Fitness Tracker with Heart Rate Blood Pressure Waterproof Bluetooth Pedometer Sleep Activity Tracker,Smartwatch Compatible for iOS Android iPhone Samsung Phones(Blue)."
    }, 
    {
        id:22, 
        img:watch23, 
        title:"AiMoonsa Smart Watch for Men,Fitness Tracker with Heart Rate Monitor, Activity Tracker Smartwatch,Waterproof,Long Battery Life,Message Notification,Smart Watches for Android Phone,iOS"
    }, 
]