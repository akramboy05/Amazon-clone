import img from "../images/1.jpg"
import img2 from "../images/2.jpg"
import img3 from "../images/3.jpg"
import img4 from "../images/4.jpg"



export const navbarOptions = [
    {
        id: 0,
        name: "All"
    },
    {
        id: 1,
        name: "All Departments"
    },
    {
        id: 2,
        name: "Arts & Crafts"
    },
    {
        id: 3,
        name: "Automotive"
    },
    {
        id: 4,
        name: "Beauty & Personal Care"
    },
    {
        id: 5,
        name: "Books"
    },
    {
        id: 6,
        name: "Boy's Fashion"
    },
    {
        id: 7,
        name: "Computers"
    },
    {
        id: 8,
        name: "Deals"
    },
    {
        id: 9,
        name: "Digital Music"
    },
    {
        id: 10,
        name: "Electronics"
    },
    {
        id: 11,
        name: "Girl's Fashion"
    },
    {
        id: 12,
        name: "Health & Household"
    },
    {
        id: 13,
        name: "Home & Kitchen"
    },
    {
        id: 14,
        name: "Indistrual & Scientific"
    },
    {
        id: 15,
        name: "Kindle Store"
    },
    {
        id: 16,
        name: "Luggage"
    },
    {
        id: 17,
        name: "Men's Fashionmovies-tv-intl-ship"
    },
    {
        id: 18,
        name: "Music , CD & Vinyl"
    },
    {
        id: 19,
        name: "Pett Sulies"
    },
    {
        id: 20,
        name: "Prime Video"
    },
    {
        id: 21,
        name: "Software"
    },
    {
        id: 22,
        name: "Sports & Outdoors"
    },
    {
        id: 23,
        name: "Prime Video"
    },
    {
        id: 24,
        name: "Tools & Improvement"
    },
    {
        id: 25,
        name: "Toys & Games"
    },
    {
        id: 26,
        name: "Video Games"
    },
    {
        id: 27,
        name: "Women's  Fashion"
    },

]

export const carusel = [
    {
        id: 0,
        img: img
    },
    {
        id: 1,
        img: img2
    },
    {
        id: 2,
        img: img3
    },
    {
        id: 3,
        img: img4
    }

]