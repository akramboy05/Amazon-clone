
import './App.css';
import Navbar from './components/navbar/Navbar'
import { BrowserRouter as Router, Route, Switch } from "react-router-dom"
import Home from './routes/home/Home';
import Login from './routes/login/Login';
import Products from './routes/products/Products';

function App() {
  return (
    <div className="App">


      <Router>
        <Navbar />
        <Switch>
          <Route exact path="/" component={Home} />
          <Route path="/login" component={Login} />
          <Route path="/products" component={Products} />
        </Switch>

      </Router>

    </div>
  );
}

export default App;
