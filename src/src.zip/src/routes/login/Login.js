import React from 'react';
import "./Login.css"
import logo from "../../images/login__logo.png"
import { Link } from "react-router-dom"

function Login() {
  return <div className='login'>
    <Link to="/">
      <img className='login__logo' src={logo} alt="" />
    </Link>
    <div className="login__form__part">
      <form className='login__form' action="">
        <h2 className='login__form__h2'>Sign-in</h2>
        <p className='login__form__p'>Email or mobile phone number</p>
        <input autoFocus className='login__form__input' type="text" />
        <button className='login__form__btn'>Continue</button>
        <p className='login__form__bottom__p'> By continuing, you agree to Amazon's <a href="#">Conditions of Use</a> and <a href="#">Privacy Notice</a>.</p>
      </form>
      <div className="login__line">
        <div className="login__line__part"></div>
        <p className='login__line__p'>New to Amazon?</p>
        <div className="login__line__part"></div>
      </div>
      <button className='login__last__btn'>Create your Amazon account</button>

    </div>


  </div>;
}

export default Login;
