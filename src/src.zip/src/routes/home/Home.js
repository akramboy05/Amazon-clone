import React from 'react';
import Banner from '../../components/banner/Banner';


function Home() {
  return <div>
    <Banner />
  </div>;
}

export default Home;
