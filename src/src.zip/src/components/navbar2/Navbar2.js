import React from 'react';
import "./Navbar2.css"
import { GoThreeBars } from "react-icons/go"
import { Link } from 'react-router-dom';

function Navbar2() {



    return (
        <div className='navbar2'>
            <div className="all">
                <GoThreeBars />
                <li>All</li>
            </div>
            <div className="collection">
                <li>Today's Deals</li>
                <li>Customer Service</li>
                <li>Registry</li>
                <li>Gift Cards</li>

                <Link to="/products">
                    <li>Sell</li>
                </Link>
            </div>
        </div>
    );
}

export default Navbar2;